function varargout = GUIDESIMULINK(varargin)
% GUIDESIMULINK MATLAB code for GUIDESIMULINK.fig
%      GUIDESIMULINK, by itself, creates a new GUIDESIMULINK or raises the existing
%      singleton*.
%
%      H = GUIDESIMULINK returns the handle to a new GUIDESIMULINK or the handle to
%      the existing singleton*.
%
%      GUIDESIMULINK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUIDESIMULINK.M with the given input arguments.
%
%      GUIDESIMULINK('Property','Value',...) creates a new GUIDESIMULINK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUIDESIMULINK_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUIDESIMULINK_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUIDESIMULINK

% Last Modified by GUIDE v2.5 27-Jan-2021 20:34:00

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUIDESIMULINK_OpeningFcn, ...
                   'gui_OutputFcn',  @GUIDESIMULINK_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUIDESIMULINK is made visible.
function GUIDESIMULINK_OpeningFcn(hObject, eventdata, handles, varargin)

img = imread('Circuito.png');
imshow(img);

load_system('RLCcircuit1');
find_system;
% open_system('RLCcircuit');
set_param([gcs,'/V1'],'Amplitude','12','Phase','0','Frequency','60');
set_param([gcs,'/powergui'],'frequency','60');
set_param([gcs,'/R1'],'Resistance','100');
set_param([gcs,'/L1'],'Inductance','0.01');
set_param([gcs,'/C1'],'Capacitance','1e-5');
set(handles.uitable1,'Data',cell(4,2),'ColumnName',{'Magnitud','Fase'},...
    'RowName',{'Vin','V(L1)','V(C1)','V(R1)'});

set_param(gcs,'SimulationCommand','Start');

% Choose default command line output for GUIDESIMULINK
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = GUIDESIMULINK_OutputFcn(~, ~, handles) 


% Get default command line output from handles structure
varargout{1} = handles.output;

function V_Callback(hObject, ~, handles)

v = get(hObject,'String');
set_param([gcs,'/V1'],'Amplitude',v);
guidata(hObject, handles);

function phi_Callback(hObject, ~, handles)

v = get(hObject,'String');
set_param([gcs,'/V1'],'Phase',v);
guidata(hObject, handles);

function f_Callback(hObject, ~, handles)

v = get(hObject,'String');
set_param([gcs,'/V1'],'Frequency',v);
set_param([gcs,'/powergui'],'frequency',v);
guidata(hObject, handles);

function R_Callback(hObject, ~, handles)

v = get(hObject,'String');
set_param([gcs,'/R1'],'Resistance',v);
guidata(hObject, handles);

function L_Callback(hObject, ~, handles)

v = get(hObject,'String');
set_param([gcs,'/L1'],'Inductance',v);
guidata(hObject, handles);

function C_Callback(hObject, ~, handles)

v = get(hObject,'String');
set_param([gcs,'/C1'],'Capacitance',v);
guidata(hObject, handles);

% --- Executes on button press in Resolver.
function Resolver_Callback(hObject, ~, handles)

set_param(gcs,'SimulationCommand','Start');
pause(2);
simout = evalin('base','out');
Vin = simout.Vin;
VL1 = simout.VL1;
VC1 = simout.VC1;
Vout = simout.Vout;
handles.uitable1.Data = num2cell([Vin; VL1; VC1; Vout]);
guidata(hObject, handles);

